For all NOOB's here

Installation is like any over mod override 
=======================================================================
Go to:   C:\Program Files (x86)\Steam\steamapps\common\PAYDAY 2\assets
in the assets folder create a folder named:   mod_overrides  if you dont already have it

then put the folder from the zip file into your mod_overrides folder.
=======================================================================